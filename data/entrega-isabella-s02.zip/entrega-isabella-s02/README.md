# Entrega para Isabella — Sprint 2

300 repositórios com coleta A e cálculos B/C completos. Janela UTC: 2025-01-01 a 2025-12-31.

Comece por dataset.csv: uma linha por projeto, sem precisar de token para analisar as métricas. manifest.json identifica as bases persistentes. Os dados brutos e o cache permanecem em data/jobs e não expiram automaticamente.

## O que ainda exige a equipe

Cada avaliador preenche seu template em gold-standard de forma independente. Depois gerem o consenso e validem CFR (b), seguindo documentacao/INTEGRACAO-ISABELLA-S02.md. A coluna cfr_b_validation está marcada pending_independent_labels; não declare F1 validado antes dessa etapa.

## Explicação simples

A caixa tem os dados dos 300 projetos. B e C já fizeram as contas. Agora cada pessoa precisa conferir as versões sorteadas e marcar seus próprios rótulos. Só depois comparamos essas respostas e verificamos se a regra automática acerta.

## Disponibilidade das comparações

2 comparações permanecem indisponíveis e estão identificadas em comparison-quality.json. Essas releases não entram no lead time; os dados de workflows continuam disponíveis para C. Valores ausentes não são preenchidos com zero. A amostra-ouro final exclui comparações indisponíveis; sampling-manifest.json registra a população elegível para o sorteio.
